<?php
/*
Plugin Name: Valhalla Contact Form
Plugin URI: --
Description: The contact form plugin for the Valhalla theme.
Version: 1.0
Author: Pierre Macedo
Author URI: --
Text Domain: valhalla-contact-form
*/
   function valhalla_contact_form_send_mail() {

 // response message
  $captcha_error   = esc_html__('The answer you entered for the CAPTCHA was not correct.', 'valhalla-contact-form');   
  $missing_content = esc_html__('Please supply all information.', 'valhalla-contact-form');
  $message_unsent  = esc_html__('Message was not sent. Try Again.', 'valhalla-contact-form');
  $message_sent    = esc_html__('Thanks! Your message has been sent.', 'valhalla-contact-form');
     
  $captcha_solution = sanitize_text_field( $_POST["solution"] );
  $captcha_user = sanitize_text_field( $_POST["message_capctha"] );   

    // if the submit button is clicked, start the functions
    if ( isset( $_POST['submitted'] ) ) {

        // sanitize form values
        $name    = sanitize_text_field( $_POST["message_name"] );
        $email   = sanitize_email( $_POST["message_email"] );
        $phone   = sanitize_text_field( $_POST["message_phone"] );
        $subject_2 = sanitize_text_field( $_POST["message_subject"] );
        $message = esc_textarea( $_POST["message_text"] );
      
    if(empty($name) || empty($message) || empty($email) ) {
          echo '<div class="contact-form-error">';
            echo $missing_content;
            echo '</div>';
        } else {
   
   if($_POST['solution'] != $_POST['message_capctha']) {
           echo '<div class="contact-form-error">';
            echo $captcha_error;
            echo '</div>';
      }
    else {
        
        // get the email ready to be sent
        $to = get_option('admin_email');
        $subject = $subject_2;
        $headers[] = 'Reply-To: ' . $email . "\r\n";
        $body = "\n\nName: $name \n\nEmail: $email \n\nPhone: $phone \n\nSubject: $subject_2 \n\nMessage: $message";

        // if the email has been processed for sending, display a success message
       if ( wp_mail( $to, $subject, $body, $headers ) ) {
            echo '<div class="contact-form-success">';
            echo $message_sent;
            echo '</div>';
        } else {
            echo '<div class="contact-form-error">';
            echo $message_unsent;
            echo '</div>';
        }
      }
      }
    }

   }


function valhalla_contact_form_html_form_code() {

  ?>
<?php
  
  $captcha_number1 = rand(1, 9);
  $captcha_number2 = rand(1, 9);
  $captcha_numbers = $captcha_number1 + $captcha_number2;
?>
<div class="container-fluid contact-form">
    <div class="row">
        <div class="col-md contact-google-maps">

            <div class="mapouter">
                <div class="gmap_canvas">
                    <iframe width="100%" height="100%" id="gmap_canvas" src="https://maps.google.com/maps?q=<?php echo esc_attr( get_theme_mod( 'valhalla_contact_s2_maps_location', '1600+Amphitheatre+Parkway+Mountain+View+CA' ) ); ?>&t=&z=13&ie=UTF8&iwloc=&output=embed" frameborder="0" scrolling="no" marginheight="0" marginwidth="0"></iframe>
                </div>
            </div>
        </div>

        <div class="col-md contact-form-display">
            <form action="<?php esc_url( $_SERVER['REQUEST_URI'] ) ?>" method="post">
                <div class="form-row form-group">
                    <div class="col">
                        <label class="contact-form-label">
                            <?php echo esc_html__('Name', 'valhalla-contact-form'); ?>*</label>
                        <input type="text" class="form-control" name="message_name" value="<?php ( isset( $_POST[" message_name"] ) ? esc_attr( $_POST["message_name"] ) : '' ) ?>">
                    </div>
                    <div class="col">
                        <label class="contact-form-label">
                            <?php echo esc_html__('Email', 'valhalla-contact-form'); ?>*</label>
                        <input type="email" class="form-control" name="message_email" value="<?php ( isset( $_POST[" message_email"] ) ? esc_attr( $_POST["message_email"] ) : '' ) ?>">
                    </div>
                </div>

                <div class="form-row form-group">
                    <div class="col">
                        <label class="contact-form-label">
                            <?php echo esc_html__('Phone', 'valhalla-contact-form'); ?></label>
                        <input type="tel" class="form-control" name="message_phone" value="<?php ( isset( $_POST[" message_phone"] ) ? esc_attr( $_POST["message_phone"] ) : '' ) ?>">
                    </div>
                    <div class="col">
                        <label class="contact-form-label">
                            <?php echo esc_html__('Subject', 'valhalla-contact-form'); ?></label>
                        <input type="text" class="form-control" name="message_subject" value="<?php ( isset( $_POST[" message_subject"] ) ? esc_attr( $_POST["message_subject"] ) : '' ) ?>">
                    </div>
                </div>

                <div class="form-row form-group">
                    <div class="col">
                        <label class="contact-form-label">
                            <?php echo esc_html__('Message', 'valhalla-contact-form'); ?>*</label>
                        <textarea class="form-control" rows="10" name="message_text" value="<?php echo ( isset( $_POST[" message_text"] ) ? esc_attr( $_POST["message_text"] ) : '' ) ?>"></textarea>
                    </div>
                </div>

                <div class="form-row form-group">
                    <div class="col">
                        <label class="contact-form-label">
                            <?php echo esc_html__('I\'m not a robot', 'valhalla-contact-form'); echo esc_html(':*&nbsp;&nbsp;'); echo esc_html($captcha_number1); echo esc_html('&nbsp;+&nbsp;'); echo esc_html($captcha_number2); echo esc_html('&nbsp;='); ?></label>
                        <input type="text" class="form-control captcha-field" name="message_capctha">
                        <input type="hidden" name="solution" value="<?php echo $captcha_numbers; ?>">
                    </div>
                </div>

                <div class="form-row">
                    <div class="col">
                        <input type="hidden" name="submitted" value="1">
                        <button type="submit" class="btn <?php echo esc_attr( get_theme_mod( 'valhalla_contact_s2_submit_style', 'btn-success' ) ); ?> mb-2">
                            <?php echo esc_html__('Submit Message', 'valhalla-contact-form'); ?></button>
                    </div>
                </div>

            </form>
        </div>
    </div>
</div>
<?php
}

function valhalla_contact_form_shortcode() {
    ob_start();
    valhalla_contact_form_send_mail();
    valhalla_contact_form_html_form_code();

    return ob_get_clean();
}
add_shortcode( 'valhalla-contact-form', 'valhalla_contact_form_shortcode' );
